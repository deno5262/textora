import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, Paperclip, Send, X, Check, CheckCheck, MoreHorizontal, MoreVertical, Reply, Copy, Pencil, Trash2, FileText, BellOff, Bell, Mic, Search, Forward, Pin, PinOff, Ban, Flag, Minimize2, Users, Clock, Palette, ImagePlus, Phone, Video, Keyboard, PhoneIncoming, PhoneOutgoing, PhoneMissed, Film, Camera as CameraIcon } from 'lucide-react'
import { supabase } from './supabase'
import { compress } from './image'
import { useAuth } from './AuthContext'
import { useOnline } from './Presence'
import { useTypingView } from './useTyping'
import { useBackClose } from './useBackClose'
import { fetchConvs, Conv, convAv, statusOf, ge, dayLabel } from './textora'
import { playNotify, playSend, playTyping, playSeen } from './sounds'
import { sendTypingTo } from './typingBus'
import { createPortal } from 'react-dom'
import { useCall } from './calls'
import HeaderTray from './HeaderTray'
import { CallRow, describeCall } from './callLog'
import ImageEditor from './ImageEditor'
import { pickGallery, takePhoto } from './pickMedia'
import ThemeMenu from './ThemeMenu'
import { cacheGet, cacheSet } from './cache'
import { Avatar } from './ui'
import { VoicePlayer, computePeaks } from './Voice'
import GroupInfo from './GroupInfo'
type R = { user_id: string; emoji: string }
type Msg = { id: string; conversation_id: string; sender_id: string; kind: string; body: string; reply_to: string | null; attachment_path: string | null; attachment_name: string | null; attachment_type: string | null; attachment_size: number | null; audio_peaks: number[] | null; audio_ms: number | null; forwarded: boolean; pinned_at: string | null; edited_at: string | null; deleted_at: string | null; created_at: string; reactions: R[]; pending?: boolean }
type Prof = { id: string; username: string; full_name: string; avatar_url: string | null; show_active: boolean; last_active_at: string | null }
type Mem = { user_id: string; role: string; last_read_at: string; last_delivered_at: string; muted: boolean; chat_bg?: string | null; profile: Prof }
type Info = { kind: string; title: string | null; avatar_url: string | null; only_admins_add: boolean; created_by: string | null }
const FILE_TYPES = ['application/pdf', 'text/plain', 'text/csv', 'application/zip', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.openxmlformats-officedocument.presentationml.presentation']
const VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime']
const QUICK = ['👍', '❤️', '😂', '😮', '😢', '🙏']
const REASONS = ['Spam or scam', 'Harassment or bullying', 'Nudity or sexual content', 'Threats or violence', 'Something else']
const size = (n: number | null) => (n ? (n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB') : '')
const human = (m: string) => (/row-level security/i.test(m) ? "You can't send messages in this chat right now." : m)
const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
const GRAD = { background: 'linear-gradient(135deg, var(--accent), var(--accent2))', color: 'var(--on)' }
function Sheet({ onClose, children }: { onClose: () => void; children: React.ReactNode }) {
  useBackClose(true, onClose)
  return <div className="fixed inset-0 z-50 flex items-end bg-black/50" onClick={onClose}><div className="mx-auto max-h-[80vh] w-full max-w-xl overflow-y-auto rounded-t-2xl bg-surface p-4 text-ink" onClick={e => e.stopPropagation()}>{children}</div></div>
}
export default function Chat() {
  const { id } = useParams(); const cid = id!; const nav = useNavigate(); const { session, profile } = useAuth(); const uid = session!.user.id; const online = useOnline()
  const [conv, setConv] = useState<Info | null | undefined>(() => cacheGet<Info>(`info:${uid}:${cid}`) ?? undefined); const [members, setMembers] = useState<Mem[]>(() => cacheGet<Mem[]>(`mem:${uid}:${cid}`) ?? []); const [muted, setMuted] = useState(false)
  const [msgs, setMsgs] = useState<Msg[]>(() => cacheGet<Msg[]>(`msgs:${uid}:${cid}`) ?? []); const [urls, setUrls] = useState<Record<string, string>>({}); const [text, setText] = useState(''); const [replyTo, setReplyTo] = useState<Msg | null>(null); const [editing, setEditing] = useState<Msg | null>(null)
  const [sheet, setSheet] = useState<Msg | null>(null); const [typing, setTyping] = useState<string | null>(null); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [peek, setPeek] = useState<string | null>(null)
  const [menu, setMenu] = useState(false); const [fwd, setFwd] = useState<Msg | null>(null); const [fwdSel, setFwdSel] = useState<Set<string>>(new Set()); const [fwdQ, setFwdQ] = useState(''); const [fwdBusy, setFwdBusy] = useState(false); const [fwdList, setFwdList] = useState<Conv[]>([]); const [rep, setRep] = useState<{ msg: Msg | null } | null>(null); const [repDone, setRepDone] = useState(''); const [groupInfo, setGroupInfo] = useState(false)
  const [searchOn, setSearchOn] = useState(false); const [sq, setSq] = useState(''); const [sres, setSres] = useState<Msg[]>([]); const [iBlocked, setIBlocked] = useState(false); const [blockedMe, setBlockedMe] = useState(false); const [recSecs, setRecSecs] = useState<number | null>(null)
  const chan = useRef<any>(null); const typingT = useRef(0); const lastSent = useRef(0); const lastPub = useRef(0); const endRef = useRef<HTMLDivElement>(null); const msgsRef = useRef<Msg[]>([]); msgsRef.current = msgs; const typingRef = useRef<string | null>(null); typingRef.current = typing
  const rec = useRef<{ mr: MediaRecorder; chunks: BlobPart[]; discard: boolean; timer: number; secs: number } | null>(null)
  useBackClose(peek !== null, () => setPeek(null))
  const [offline, setOffline] = useState(!navigator.onLine); const [themeOpen, setThemeOpen] = useState(false); const [bgUrl, setBgUrl] = useState<string | null>(null); const outKey = `out:${uid}:${cid}`
  const seenRef = useRef(-1)
  useEffect(() => {
    const lm = [...msgs].reverse().find(m => m.sender_id === uid && m.kind !== 'system')
    const n = lm ? members.filter(x => x.user_id !== uid && ge(x.last_read_at, lm.created_at)).length : 0
    if (seenRef.current < 0) { if (msgs.length && members.length) seenRef.current = n; return }
    if (n > seenRef.current && lm) playSeen(); seenRef.current = n
  }, [msgs, members])
  useEffect(() => { if (msgs.length) cacheSet(`msgs:${uid}:${cid}`, msgs.filter(m => !m.pending).slice(-60)) }, [msgs])
  const myBg = members.find(m => m.user_id === uid)?.chat_bg ?? null
  useEffect(() => { if (myBg?.startsWith('g:')) supabase.storage.from('chat').createSignedUrl(myBg.slice(2), 3600).then(({ data }) => setBgUrl(data?.signedUrl ?? null)); else setBgUrl(null) }, [myBg])
  useEffect(() => { const id = setInterval(() => flushOutbox(), 8000); return () => clearInterval(id) }, [])
  const flushOutbox = async () => {
    const q = cacheGet<{ tmp: string; body: string; reply_to: string | null }[]>(outKey) ?? []; if (!q.length || !navigator.onLine) return
    const left: typeof q = []
    for (const o of q) {
      const { data, error } = await supabase.from('messages').insert({ conversation_id: cid, sender_id: uid, kind: 'text', body: o.body, reply_to: o.reply_to }).select('*').single()
      if (error) { left.push(o); continue }
      const real = { ...(data as Msg), reactions: [] as R[] }; setMsgs(cur => [...cur.filter(x => x.id !== o.tmp && x.id !== real.id), real])
    }
    cacheSet(outKey, left)
  }
  useEffect(() => {
    const on = () => { setOffline(false); flushOutbox() }; const off = () => setOffline(true)
    window.addEventListener('online', on); window.addEventListener('offline', off); flushOutbox()
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off) }
  }, [cid])
  const isGroup = conv?.kind === 'group'; const other = !isGroup ? members.find(m => m.user_id !== uid)?.profile : undefined; const typingMap = useTypingView(!isGroup)
  const [nicks, setNicks] = useState<Record<string, string>>({}); const [nickOpen, setNickOpen] = useState(false); const [nickEdit, setNickEdit] = useState<{ id: string; v: string } | null>(null)
  const loadNicks = () => supabase.from('nicknames').select('target_id,nickname').eq('conversation_id', cid).then(({ data }) => { if (data) setNicks(Object.fromEntries((data as any[]).map(r => [r.target_id, r.nickname]))) })
  useEffect(() => { loadNicks() }, [cid])
  const prof = (pid: string) => members.find(m => m.user_id === pid)?.profile; const nameOf = (pid: string) => (pid === uid ? 'You' : nicks[pid] || prof(pid)?.full_name || prof(pid)?.username || 'Someone')
  const sign = async (paths: string[]) => {
    if (!paths.length) return
    const { data } = await supabase.storage.from('chat').createSignedUrls(paths, 3600)
    setUrls(u => { const n = { ...u }; data?.forEach(x => { if (x.path && x.signedUrl) n[x.path] = x.signedUrl }); return n })
  }
  const addMsg = (m: Msg) => { setMsgs(cur => (cur.some(x => x.id === m.id) ? cur : [...cur, m])); if (m.attachment_path) sign([m.attachment_path]) }
  const patchMsg = (m: Partial<Msg> & { id: string }) => setMsgs(cur => cur.map(x => (x.id === m.id ? { ...x, ...m } : x)))
  const markRead = () => { if (document.visibilityState !== 'visible') return; const n = new Date().toISOString(); supabase.from('conversation_members').update({ last_read_at: n, last_delivered_at: n }).eq('conversation_id', cid).eq('user_id', uid).then(() => window.dispatchEvent(new Event('textora-unread'))) }
  useEffect(() => { const f = () => { if (document.visibilityState === 'visible') markRead() }; document.addEventListener('visibilitychange', f); return () => document.removeEventListener('visibilitychange', f) }, [cid])
  const reloadReactions = async () => {
    const ids = msgsRef.current.map(m => m.id); if (!ids.length) return
    const { data } = await supabase.from('message_reactions').select('message_id,user_id,emoji').in('message_id', ids)
    const by: Record<string, R[]> = {}; ((data ?? []) as any[]).forEach(r => { if (!by[r.message_id]) by[r.message_id] = []; by[r.message_id].push({ user_id: r.user_id, emoji: r.emoji }) })
    setMsgs(cur => cur.map(m => ({ ...m, reactions: by[m.id] ?? [] })))
  }
  const loadBlocks = async (oid: string) => {
    const { data } = await supabase.from('blocks').select('blocker_id,blocked_id').or(`and(blocker_id.eq.${uid},blocked_id.eq.${oid}),and(blocker_id.eq.${oid},blocked_id.eq.${uid})`)
    const rows = (data ?? []) as any[]; setIBlocked(rows.some(r => r.blocker_id === uid)); setBlockedMe(rows.some(r => r.blocker_id === oid))
  }
  const loadInfo = async () => {
    const [c, m] = await Promise.all([
      supabase.from('conversations').select('kind,title,avatar_url,only_admins_add,created_by').eq('id', cid).maybeSingle(),
      supabase.from('conversation_members').select('user_id,role,last_read_at,last_delivered_at,muted,chat_bg,profile:profiles!conversation_members_user_id_fkey(id,username,full_name,avatar_url,show_active,last_active_at)').eq('conversation_id', cid)])
    if (c.error || m.error) { if (conv === undefined) throw new Error((c.error ?? m.error)!.message); return }
    if (!c.data) return setConv(null)
    const rows = (m.data ?? []) as any as Mem[]; setConv(c.data as Info); setMembers(rows); setMuted(!!rows.find(r => r.user_id === uid)?.muted); cacheSet(`info:${uid}:${cid}`, c.data); cacheSet(`mem:${uid}:${cid}`, rows)
    const o = rows.find(r => r.user_id !== uid); if ((c.data as any).kind === 'direct' && o) loadBlocks(o.user_id)
  }
  useEffect(() => {
    (async () => {
      const msgQ = Promise.resolve(supabase.from('messages').select('*, reactions:message_reactions(user_id,emoji)').eq('conversation_id', cid).order('created_at', { ascending: false }).limit(60))
      const [, { data, error: loadErr }] = await Promise.all([loadInfo(), msgQ])
      if (loadErr) return
      const list = ((data ?? []) as Msg[]).reverse(); setMsgs([...list, ...msgsRef.current.filter(m => m.pending)]); sign(list.map(m => m.attachment_path).filter(Boolean) as string[]); markRead()
    })().catch(e => setErr(e.message))
    const ch = supabase.channel('chat-' + cid)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${cid}` }, (p: any) => { addMsg({ ...p.new, reactions: [] }); if (p.new.kind === 'system') loadInfo(); if (p.new.sender_id !== uid) { playNotify(); setTyping(null); markRead() } })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${cid}` }, (p: any) => patchMsg(p.new))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'message_reactions' }, () => { reloadReactions() })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'conversation_members', filter: `conversation_id=eq.${cid}` }, (p: any) => setMembers(cur => cur.map(x => (x.user_id === p.new.user_id ? { ...x, last_read_at: p.new.last_read_at, last_delivered_at: p.new.last_delivered_at, role: p.new.role } : x))))
      .on('broadcast', { event: 'typing' }, (p: any) => { const who = p.payload?.uid; if (who && who !== uid) { if (!typingRef.current) playTyping(); setTyping(who); window.clearTimeout(typingT.current); typingT.current = window.setTimeout(() => setTyping(null), 4000) } })
      .subscribe()
    chan.current = ch
    return () => { window.clearTimeout(typingT.current); supabase.removeChannel(ch); supabase.from('typing_status').delete().eq('user_id', uid).then(() => {}); if (rec.current) { rec.current.discard = true; window.clearInterval(rec.current.timer); if (rec.current.mr.state === 'recording') rec.current.mr.stop() } }
  }, [cid])
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs.length, typing])
  useEffect(() => {
    const term = sq.trim().replace(/[%_\\]/g, ' ').trim(); if (!searchOn || term.length < 2) { setSres([]); return }
    const t = setTimeout(() => { supabase.from('messages').select('*').eq('conversation_id', cid).is('deleted_at', null).ilike('body', `%${term}%`).order('created_at', { ascending: false }).limit(30).then(({ data }) => setSres(((data ?? []) as any[]).map(m => ({ ...m, reactions: [] })))) }, 300)
    return () => clearTimeout(t)
  }, [sq, searchOn])
  const jump = (mid: string) => { setSearchOn(false); setSq(''); setTimeout(() => { const el = document.getElementById('m-' + mid); if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('ring-2'); setTimeout(() => el.classList.remove('ring-2'), 1500) } }, 50) }
  const onType = (v: string) => {
    setText(v); const now = Date.now()
    if (v && now - lastSent.current > 2500) { lastSent.current = now; chan.current?.send({ type: 'broadcast', event: 'typing', payload: { uid } }); if (!isGroup && other) sendTypingTo(other.id, cid, uid) }
    if (v && profile?.typing_status_enabled && !isGroup && other && now - lastPub.current > 3000) { lastPub.current = now; supabase.from('typing_status').upsert({ user_id: uid, with_user: other.id, updated_at: new Date().toISOString() }).then(() => {}) }
  }
  const clearTypingStatus = () => { lastPub.current = 0; if (profile?.typing_status_enabled) supabase.from('typing_status').delete().eq('user_id', uid).then(() => {}) }
  const insert = async (row: Record<string, any>) => {
    const { data, error } = await supabase.from('messages').insert({ conversation_id: cid, sender_id: uid, reply_to: replyTo?.id ?? null, ...row }).select('*').single()
    if (error) throw error; addMsg({ ...(data as Msg), reactions: [] }); setReplyTo(null); playSend(); clearTypingStatus()
  }
  const send = async () => {
    const t = text.trim(); if (!t) return; setErr('')
    if (editing) {
      const { error } = await supabase.from('messages').update({ body: t, edited_at: new Date().toISOString() }).eq('id', editing.id)
      if (error) return setErr(human(error.message)); patchMsg({ id: editing.id, body: t, edited_at: new Date().toISOString() }); setEditing(null); setText(''); return
    }
    setText('')
    const tmp = 'tmp-' + crypto.randomUUID(); const o = { tmp, body: t, reply_to: replyTo?.id ?? null }
    addMsg({ id: tmp, conversation_id: cid, sender_id: uid, kind: 'text', body: t, reply_to: o.reply_to, attachment_path: null, attachment_name: null, attachment_type: null, attachment_size: null, audio_peaks: null, audio_ms: null, forwarded: false, pinned_at: null, edited_at: null, deleted_at: null, created_at: new Date().toISOString(), reactions: [], pending: true })
    setReplyTo(null); playSend(); clearTypingStatus()
    const queue = () => cacheSet(outKey, [...(cacheGet<any[]>(outKey) ?? []), o])
    if (!navigator.onLine) { queue(); return }
    try {
      const { data, error } = await supabase.from('messages').insert({ conversation_id: cid, sender_id: uid, kind: 'text', body: t, reply_to: o.reply_to }).select('*').single()
      if (error || !data) { queue(); setErr(human(error?.message ?? 'Not sent yet, will retry')); return }
      const real = { ...(data as Msg), reactions: [] as R[] }; setMsgs(cur => [...cur.filter(x => x.id !== tmp && x.id !== real.id), real])
    } catch { queue() }
  }
  const upload = async (blob: Blob | File, ext: string, type: string) => {
    const path = `${uid}/${cid}/${crypto.randomUUID()}.${ext}`; const { error } = await supabase.storage.from('chat').upload(path, blob, { contentType: type }); if (error) throw error; return path
  }
  const sendAttachment = async (f: File, asDoc = false) => {
    setErr('')
    const img = f.type.startsWith('image/'); const vid = VIDEO_TYPES.includes(f.type); const asPhoto = img && !asDoc
    if (!asDoc && !img && !vid && !FILE_TYPES.includes(f.type)) return setErr('This file type is not supported. Use images, videos, PDF, Office files, TXT, CSV or ZIP.')
    if (f.size > 50 * 1024 * 1024) return setErr('File is too large (max 50 MB).')
    setBusy(true); let path = ''
    try {
      const blob = asPhoto ? await compress(f, 1600) : f
      const ext = asPhoto ? 'jpg' : ((f.name.split('.').pop() ?? 'bin').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8) || 'bin'); const type = asPhoto ? 'image/jpeg' : (f.type || 'application/octet-stream')
      path = await upload(blob, ext, type)
      await insert({ kind: asPhoto ? 'image' : (vid && !asDoc) ? 'video' : 'file', attachment_path: path, attachment_name: f.name.slice(0, 120), attachment_type: type, attachment_size: blob.size })
    } catch (x) { if (path) await supabase.storage.from('chat').remove([path]); setErr(human((x as Error).message)) }
    setBusy(false)
  }
  const handlePicked = (files: File[]) => { const imgs = files.filter(f => f.type.startsWith('image/')); files.filter(f => !f.type.startsWith('image/')).forEach(f => sendAttachment(f)); if (imgs.length) setEditQueue(imgs) }
  const attach = (e: React.ChangeEvent<HTMLInputElement>) => { const fs = Array.from(e.target.files ?? []); e.target.value = ''; if (fs.length) handlePicked(fs) }
  const attachDoc = (e: React.ChangeEvent<HTMLInputElement>) => { const fs = Array.from(e.target.files ?? []); e.target.value = ''; fs.forEach(f => sendAttachment(f, true)) }
  const pickG = async () => { setAttachOpen(false); const r = await pickGallery(); if (r === null) galRef.current?.click(); else if (r.length) handlePicked(r) }
  const pickC = async () => { setAttachOpen(false); const r = await takePhoto(); if (r === null) camRef.current?.click(); else if (r.length) handlePicked(r) }
  const finishVoice = async (blob: Blob, secs: number) => {
    if (blob.size < 1500) return setErr('Recording was too short.')
    setBusy(true); let path = ''
    try {
      const wf = await computePeaks(blob); const mime = blob.type.split(';')[0] || 'audio/webm'; const ext = mime.includes('mp4') ? 'm4a' : mime.includes('ogg') ? 'ogg' : 'webm'
      path = await upload(blob, ext, mime)
      await insert({ kind: 'voice', attachment_path: path, attachment_type: mime, attachment_size: blob.size, audio_peaks: wf.peaks, audio_ms: Math.round(wf.ms) || secs * 1000 })
    } catch (x) { if (path) await supabase.storage.from('chat').remove([path]); setErr(human((x as Error).message)) }
    setBusy(false)
  }
  const startRec = async () => {
    setErr('')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true }); const mr = new MediaRecorder(stream); const r = { mr, chunks: [] as BlobPart[], discard: false, timer: 0, secs: 0 }
      mr.ondataavailable = e => r.chunks.push(e.data)
      mr.onstop = () => { stream.getTracks().forEach(t => t.stop()); window.clearInterval(r.timer); setRecSecs(null); if (!r.discard) finishVoice(new Blob(r.chunks, { type: mr.mimeType || 'audio/webm' }), r.secs) }
      mr.start(); rec.current = r; setRecSecs(0); r.timer = window.setInterval(() => { r.secs += 1; setRecSecs(r.secs); if (r.secs >= 180 && mr.state === 'recording') mr.stop() }, 1000)
    } catch { setErr('Microphone permission is needed to record a voice message.') }
  }
  const stopRec = (discard: boolean) => { const r = rec.current; if (!r) return; r.discard = discard; if (r.mr.state === 'recording') r.mr.stop() }
  const react = async (m: Msg, emoji: string) => {
    const mine = m.reactions.find(r => r.user_id === uid); const same = mine?.emoji === emoji
    patchMsg({ id: m.id, reactions: same ? m.reactions.filter(r => r.user_id !== uid) : [...m.reactions.filter(r => r.user_id !== uid), { user_id: uid, emoji }] })
    const r = same ? await supabase.from('message_reactions').delete().eq('message_id', m.id).eq('user_id', uid) : await supabase.from('message_reactions').upsert({ message_id: m.id, user_id: uid, emoji }, { onConflict: 'message_id,user_id' })
    if (r.error) setErr(r.error.message); setSheet(null)
  }
  const del = async (m: Msg) => {
    setSheet(null); if (!confirm('Delete this message for everyone?')) return
    const at = new Date().toISOString(); const { error } = await supabase.from('messages').update({ body: '', deleted_at: at }).eq('id', m.id); if (error) return setErr(error.message)
    if (m.attachment_path) await supabase.storage.from('chat').remove([m.attachment_path]); patchMsg({ id: m.id, body: '', deleted_at: at, pinned_at: null })
  }
  const pin = async (m: Msg) => { setSheet(null); const { error } = await supabase.rpc('pin_message', { mid: m.id, pin: !m.pinned_at }); if (error) setErr(error.message) }
  const openFwd = async (m: Msg) => { setSheet(null); setFwd(m); setFwdList(cacheGet<Conv[]>(`convs:${uid}`) ?? []); const fresh = await fetchConvs().catch(() => null); if (fresh) setFwdList(fresh) }
  const forwardOne = async (m: Msg, target: string): Promise<string | null> => {
    let path: string | null = null
    try {
      if (m.attachment_path) { path = `${uid}/${target}/${crypto.randomUUID()}.${m.attachment_path.split('.').pop() ?? 'bin'}`; const { error } = await supabase.storage.from('chat').copy(m.attachment_path, path); if (error) throw error }
      const { error } = await supabase.from('messages').insert({ conversation_id: target, sender_id: uid, kind: m.kind, body: m.kind === 'text' ? m.body : '', attachment_path: path, attachment_name: m.attachment_name, attachment_type: m.attachment_type, attachment_size: m.attachment_size, audio_peaks: m.audio_peaks, audio_ms: m.audio_ms, forwarded: true })
      if (error) throw error; return null
    } catch (x) { if (path) await supabase.storage.from('chat').remove([path]); return human((x as Error).message) }
  }
  const sendForward = async () => {
    const m = fwd; if (!m || !fwdSel.size) return; setFwdBusy(true); let ok = 0; let bad = ''
    for (const target of fwdSel) { const r = await forwardOne(m, target); if (r) bad = r; else ok++ }
    setFwdBusy(false); setFwd(null); setFwdSel(new Set()); setFwdQ('')
    if (ok) { playSend(); flash(ok === 1 ? 'Forwarded ✓' : `Forwarded to ${ok} chats ✓`) } if (bad) flash('Some failed: ' + bad)
  }
  const PRE: Record<string, string> = { aurora: 'linear-gradient(160deg,#0f2027,#2c5364)', dusk: 'linear-gradient(160deg,#42275a,#734b6d)', night: 'linear-gradient(160deg,#0f0c29,#302b63,#24243e)', forest: 'linear-gradient(160deg,#134e5e,#71b280)', rose: 'linear-gradient(160deg,#b24592,#f15f79)', ember: 'linear-gradient(160deg,#42275a,#e5383b)', black: '#000' }
  const setBg = (v: string | null) => { setMembers(cur => cur.map(x => (x.user_id === uid ? { ...x, chat_bg: v } : x))); setThemeOpen(false); supabase.from('conversation_members').update({ chat_bg: v }).eq('conversation_id', cid).eq('user_id', uid).then(({ error }) => { if (error) flash('Theme not saved: ' + error.message) }) }
  const uploadBg = async (f: File) => {
    setThemeOpen(false); flash('Uploading theme…')
    try { const path = `${uid}/theme-${crypto.randomUUID()}.jpg`; const { error } = await supabase.storage.from('chat').upload(path, await compress(f, 1280), { contentType: 'image/jpeg' }); if (error) throw error; setBg('g:' + path); flash('Theme set ✓') } catch (x) { flash('Upload failed: ' + human((x as Error).message)) }
  }
  const pickBg = (e: React.ChangeEvent<HTMLInputElement>) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) uploadBg(f) }
  const chooseBg = async () => { const r = await pickGallery(); if (r === null) bgRef.current?.click(); else if (r[0]) uploadBg(r[0]) }
  const toggleMute = async () => { const v = !muted; setMuted(v); setMenu(false); await supabase.from('conversation_members').update({ muted: v }).eq('conversation_id', cid).eq('user_id', uid) }
  const toggleBlock = async () => {
    setMenu(false); if (!other) return
    if (iBlocked) { await supabase.from('blocks').delete().eq('blocker_id', uid).eq('blocked_id', other.id) } else { if (!confirm(`Block ${other.full_name || other.username}? They won't be able to message you.`)) return; const { error } = await supabase.from('blocks').insert({ blocker_id: uid, blocked_id: other.id }); if (error) return setErr(error.message) }
    loadBlocks(other.id)
  }
  const report = async (reason: string) => {
    if (!rep) return; const target = rep.msg ? rep.msg.sender_id : other?.id ?? conv?.created_by
    if (!target) return setRepDone('Could not send the report.')
    const { error } = await supabase.from('user_reports').insert({ reporter_id: uid, target_id: target, conversation_id: cid, message_id: rep.msg?.id ?? null, reason })
    setRepDone(error ? error.message : 'Thanks. We will review this report.')
  }
  const { startCall } = useCall()
  const [tAllow, setTAllow] = useState(false); const [toast, setToast] = useState('')
  const flash = (m: string) => { setToast(m); window.setTimeout(() => setToast(''), 2400) }
  const [callRows, setCallRows] = useState<CallRow[]>([])
  const [extraMsgs, setExtraMsgs] = useState<Record<string, Msg>>({})
  useEffect(() => { const miss = [...new Set(msgs.map(m => m.reply_to).filter((r): r is string => !!r && !msgs.some(x => x.id === r) && !extraMsgs[r]))]; if (!miss.length) return; supabase.from('messages').select('*').in('id', miss).then(({ data }) => { if (data) setExtraMsgs(cur => ({ ...cur, ...Object.fromEntries((data as Msg[]).map(m => [m.id, m])) })) }) }, [msgs.length])
  const [attachOpen, setAttachOpen] = useState(false); const [editQueue, setEditQueue] = useState<File[]>([])
  const bgRef = useRef<HTMLInputElement>(null), galRef = useRef<HTMLInputElement>(null), camRef = useRef<HTMLInputElement>(null), vidRef = useRef<HTMLInputElement>(null), docRef = useRef<HTMLInputElement>(null)
  useEffect(() => { if (isGroup) return; const load = () => supabase.from('calls').select('*').eq('conversation_id', cid).order('created_at', { ascending: false }).limit(30).then(({ data }) => { if (data) setCallRows(cur => (JSON.stringify(cur) === JSON.stringify(data) ? cur : (data as CallRow[]))) }); load(); const i = window.setInterval(load, 12000); return () => window.clearInterval(i) }, [cid, isGroup])
  useEffect(() => { if (isGroup || !other) return; supabase.from('typing_allow').select('viewer').eq('owner', uid).eq('viewer', other.id).maybeSingle().then(({ data }) => setTAllow(!!data)) }, [other?.id])
  const saveNick = async () => {
    if (!nickEdit) return; const v = nickEdit.v.trim().slice(0, 30); const id = nickEdit.id; setNickEdit(null)
    setNicks(cur => { const n = { ...cur }; if (v) n[id] = v; else delete n[id]; return n })
    const r = v ? await supabase.from('nicknames').upsert({ conversation_id: cid, target_id: id, nickname: v, set_by: uid, updated_at: new Date().toISOString() }, { onConflict: 'conversation_id,target_id' }) : await supabase.from('nicknames').delete().eq('conversation_id', cid).eq('target_id', id)
    if (r.error) { flash('Nickname not saved: ' + r.error.message); loadNicks() }
  }
  const toggleTypingAllow = async () => { if (!other) return; setMenu(false); const on = !tAllow; setTAllow(on); if (on) await supabase.from('typing_allow').insert({ owner: uid, viewer: other.id }); else await supabase.from('typing_allow').delete().eq('owner', uid).eq('viewer', other.id) }
  const [pick, setPick] = useState<{ m: Msg; top: number; mine: boolean } | null>(null)
  const [drag, setDrag] = useState<{ id: string; dx: number } | null>(null)
  const gs = useRef({ x: 0, y: 0, timer: 0, swiping: false, long: false, dx: 0 })
  if (conv === undefined) return <div className="fixed inset-0 z-40 grid place-items-center bg-bg p-6 text-center text-mute">{err ? 'Could not open this chat: ' + err : offline ? 'No saved copy of this chat yet. Connect to the internet to open it.' : 'Loading…'}</div>
  if (!conv || (!isGroup && !other)) return <div className="fixed inset-0 z-40 grid place-items-center bg-bg p-6 text-center"><div><p className="mb-3 text-mute">{conv === undefined ? 'Opening…' : 'Conversation not found.'}{err ? ' ' + err : ''}</p><div className="flex justify-center gap-2"><button className="btn" onClick={() => location.reload()}>Retry</button><button className="btn" onClick={() => nav('/textora')}>Back</button></div></div></div>
  const view: Msg[] = [...msgs, ...callRows.map(c => ({ id: 'call-' + c.id, conversation_id: cid, sender_id: c.caller_id, kind: 'call', body: '', created_at: c.created_at, reactions: [], calldata: c } as any))].sort((a, b) => (a.created_at < b.created_at ? -1 : a.created_at > b.created_at ? 1 : 0))
  const bgStyle = myBg?.startsWith('p:') && PRE[myBg.slice(2)] ? { background: PRE[myBg.slice(2)] } : bgUrl ? { backgroundImage: `linear-gradient(rgba(0,0,0,.35), rgba(0,0,0,.35)), url(${bgUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' } : undefined
  const myShow = profile?.show_active !== false; const typer = typing ? nameOf(typing).split(' ')[0] : ''
  const status = typing ? (isGroup ? `${typer} is typing…` : 'Typing…') : isGroup ? `${members.length} members` : other && typingMap[other.id] ? typingMap[other.id] : myShow && other ? statusOf(online.has(other.id), other.show_active, other.last_active_at) : ''
  const headName = isGroup ? conv.title ?? 'Group' : nicks[other!.id] || other!.full_name || other!.username
  const headAv = isGroup ? { avatar_url: conv.avatar_url, full_name: conv.title ?? 'G', username: 'group' } : other!
  const label = (q: Msg) => (q.deleted_at ? 'Deleted message' : q.kind === 'image' ? '📷 Photo' : q.kind === 'video' ? '🎥 Video' : q.kind === 'voice' ? '🎤 Voice message' : q.kind === 'file' ? '📎 ' + (q.attachment_name ?? 'File') : q.body)
  const quote = (m: Msg) => { const q = m.reply_to ? (msgs.find(x => x.id === m.reply_to) ?? extraMsgs[m.reply_to]) : null; return q ? { who: nameOf(q.sender_id), text: label(q) } : { who: '', text: 'Message not available' } }
  const pinned = [...msgs].filter(m => m.pinned_at && !m.deleted_at).sort((a, b) => b.pinned_at!.localeCompare(a.pinned_at!))[0]
  const readers = (m: Msg) => members.filter(x => x.user_id !== uid && ge(x.last_read_at, m.created_at)); const delivered = (m: Msg) => members.some(x => x.user_id !== uid && ge(x.last_delivered_at, m.created_at))
  const lastMine = [...msgs].reverse().find(m => m.sender_id === uid && m.kind !== 'system')?.id
  const tStart = (e: React.TouchEvent, m: Msg, mine: boolean) => {
    if (m.pending || m.deleted_at) return
    const t0 = e.touches[0]; const top = (e.currentTarget as HTMLElement).getBoundingClientRect().top
    window.clearTimeout(gs.current.timer)
    gs.current = { x: t0.clientX, y: t0.clientY, swiping: false, long: false, dx: 0, timer: window.setTimeout(() => { gs.current.long = true; navigator.vibrate?.(18); setPick({ m, top, mine }) }, 380) }
  }
  const tMove = (e: React.TouchEvent, m: Msg) => {
    if (gs.current.long) return
    const t0 = e.touches[0]; const dx = t0.clientX - gs.current.x, dy = t0.clientY - gs.current.y
    if (!gs.current.swiping && (Math.abs(dy) > 10 || dx < -10)) { window.clearTimeout(gs.current.timer); return }
    if (dx > 10) { window.clearTimeout(gs.current.timer); gs.current.swiping = true }
    if (gs.current.swiping) { const v = Math.min(80, dx * 0.6); gs.current.dx = v; setDrag({ id: m.id, dx: v }) }
  }
  const tEnd = (m: Msg) => {
    window.clearTimeout(gs.current.timer)
    if (gs.current.swiping && gs.current.dx > 44) { navigator.vibrate?.(12); setReplyTo(m) }
    gs.current.swiping = false; setDrag(null)
  }
  const actions: [typeof Reply, string, () => void, boolean][] = sheet ? [[Reply, 'Reply', () => { setReplyTo(sheet); setSheet(null) }, true], [Copy, 'Copy text', () => { navigator.clipboard?.writeText(sheet.body).catch(() => {}); setSheet(null) }, sheet.kind === 'text'],
    [Forward, 'Forward', () => openFwd(sheet), true], [sheet.pinned_at ? PinOff : Pin, sheet.pinned_at ? 'Unpin' : 'Pin', () => pin(sheet), true],
    [Pencil, 'Edit', () => { setEditing(sheet); setText(sheet.body); setSheet(null) }, sheet.sender_id === uid && sheet.kind === 'text'], [Trash2, 'Delete for everyone', () => del(sheet), sheet.sender_id === uid],
    [Flag, 'Report message', () => { setRep({ msg: sheet }); setRepDone(''); setSheet(null) }, sheet.sender_id !== uid]] : []
  return (<div className="fixed inset-0 z-40 mx-auto flex max-w-xl flex-col bg-bg text-ink">
    <header className="flex items-center gap-1 border-b border-line bg-bg px-2 pb-2" style={{ paddingTop: 'max(0.5rem, env(safe-area-inset-top))' }}>
      <button onClick={() => nav('/textora')} aria-label="Back" className="p-2"><ArrowLeft /></button>
      <button onClick={() => (isGroup ? setGroupInfo(true) : other && nav('/textora/u/' + other.username))} className="flex min-w-0 flex-1 items-center gap-3 text-left"><span className="relative"><Avatar a={headAv} s={40} />{!isGroup && myShow && other!.show_active && online.has(other!.id) && <i className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-bg bg-green-500" />}</span>
        <div className="min-w-0"><b className="flex items-center gap-1 truncate">{headName}{isGroup && <Users size={13} className="shrink-0 text-mute" />}</b><span className={`block truncate text-xs ${typing || (other && typingMap[other.id]) ? 'text-accent' : 'text-mute'}`}>{status}</span></div></button>
      <HeaderTray>
        <button onClick={() => setSearchOn(!searchOn)} aria-label="Search in chat" className="p-2 text-mute"><Search size={20} /></button>
        <span className="grid h-10 w-10 place-items-center"><ThemeMenu /></span>
        {!isGroup && other && <button onClick={() => startCall(other as any, cid, 'audio')} aria-label="Voice call" className="p-2 text-accent"><Phone size={20} /></button>}
        {!isGroup && other && <button onClick={() => startCall(other as any, cid, 'video')} aria-label="Video call" className="p-2 text-accent"><Video size={21} /></button>}
        <button onClick={() => setMenu(true)} aria-label="Menu" className="p-2 text-mute"><MoreVertical size={20} /></button></HeaderTray>
    </header>
    {searchOn && <div className="border-b border-line bg-surface p-2"><input autoFocus className="w-full rounded-full border border-line bg-bg px-4 py-2 outline-none" placeholder="Search in this chat" value={sq} onChange={e => setSq(e.target.value)} />
      <div className="max-h-48 overflow-y-auto">{sres.map(m => <button key={m.id} onClick={() => jump(m.id)} className="block w-full border-b border-line px-2 py-2 text-left text-sm"><span className="text-xs text-mute">{dayLabel(m.created_at)} · {nameOf(m.sender_id)}</span><p className="truncate">{m.body}</p></button>)}
        {sq.trim().length >= 2 && !sres.length && <p className="p-3 text-center text-sm text-mute">No messages found.</p>}</div></div>}
    {pinned && <button onClick={() => jump(pinned.id)} className="flex items-center gap-2 border-b border-line bg-surface px-3 py-1.5 text-left text-sm"><Pin size={14} className="shrink-0 text-accent" /><span className="truncate"><b>Pinned</b> · {label(pinned)}</span></button>}
    <div className="flex-1 overflow-y-auto px-3 py-2" style={bgStyle}>
      {!msgs.length && <p className="py-16 text-center text-mute">No messages yet. Say hello 👋</p>}
      {view.map((m, i) => {
        const prev = view[i - 1], next = view[i + 1]; const d = dayLabel(m.created_at); const showDay = !prev || dayLabel(prev.created_at) !== d
        const dayEl = showDay ? <p className="my-3 text-center text-xs text-mute">{d}</p> : null
        if (m.kind === 'call') { const cr = (m as any).calldata as CallRow; const d = describeCall(cr, uid); const mineC = cr.caller_id === uid
          const Icon = cr.kind === 'video' ? Video : d.missed ? PhoneMissed : mineC ? PhoneOutgoing : PhoneIncoming
          return <div key={m.id}>{dayEl}<div className={`mt-2 flex ${mineC ? 'justify-end' : 'justify-start'}`}><button onClick={() => other && startCall(other as any, cid, cr.kind)} className={`flex max-w-[78%] items-center gap-3 rounded-2xl px-3 py-2 text-left ${mineC ? '' : 'bg-surface'}`} style={mineC ? GRAD : undefined}>
            <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-full bg-black/25 ${d.missed ? 'text-red-400' : ''}`}><Icon size={20} /></span>
            <span className="min-w-0 flex-1"><b className={`block ${d.missed ? 'text-red-400' : ''}`}>{d.title}</b><span className={`block text-sm ${d.missed || d.sub === 'No answer' ? 'text-red-300' : 'opacity-80'}`}>{d.sub}</span></span>
            <span className="self-end pb-0.5 text-[11px] opacity-70">{d.time}</span></button></div></div> }
        if (m.kind === 'system') return <div key={m.id}>{dayEl}<p className="my-2 text-center text-xs text-mute">{nameOf(m.sender_id)} {m.body}</p></div>
        const mine = m.sender_id === uid; const near = (a?: Msg) => !!a && a.kind !== 'system' && a.kind !== 'call' && a.sender_id === m.sender_id && dayLabel(a.created_at) === d && Math.abs(new Date(a.created_at).getTime() - new Date(m.created_at).getTime()) < 300000
        const sameP = near(prev), sameN = near(next); const qt = m.reply_to ? quote(m) : null; const src = urls[m.attachment_path ?? '']; const sender = prof(m.sender_id)
        const counts: Record<string, number> = {}; m.reactions.forEach(r => { counts[r.emoji] = (counts[r.emoji] ?? 0) + 1 })
        const rad = mine ? `rounded-[20px] ${sameP ? 'rounded-tr-[6px]' : ''} ${sameN ? 'rounded-br-[6px]' : ''}` : `rounded-[20px] ${sameP ? 'rounded-tl-[6px]' : ''} ${sameN ? 'rounded-bl-[6px]' : ''}`
        const rd = m.id === lastMine ? readers(m) : []
        return (<div key={m.id}>{dayEl}
          {isGroup && !mine && !sameP && <p className="ml-9 mt-1 text-xs text-mute">{nameOf(m.sender_id)}</p>}
          <div id={'m-' + m.id} className={`relative ${sameP ? 'mt-0.5' : 'mt-2'} flex items-end gap-1 rounded-2xl ring-accent ${mine ? 'flex-row-reverse' : ''}`} style={drag?.id === m.id ? { transform: `translateX(${drag.dx}px)` } : { transition: 'transform .18s' }}>{drag?.id === m.id && drag.dx > 24 && <span className="absolute -left-10 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-full bg-surface text-accent"><Reply size={16} /></span>}
            {!mine && <div className="w-7 shrink-0">{!sameN && <Avatar a={sender ?? { avatar_url: null, full_name: '?', username: '?' }} s={28} />}</div>}
            <div className={`max-w-[76%] px-3 py-2 ${rad} ${mine ? '' : 'bg-surface'}`} style={{ ...(mine ? GRAD : {}), touchAction: 'pan-y', userSelect: 'none', WebkitUserSelect: 'none', WebkitTouchCallout: 'none' } as React.CSSProperties} onTouchStart={e => tStart(e, m, mine)} onTouchMove={e => tMove(e, m)} onTouchEnd={() => tEnd(m)} onTouchCancel={() => tEnd(m)} onContextMenu={e => e.preventDefault()}>
              {m.forwarded && !m.deleted_at && <p className="mb-0.5 text-[10px] italic opacity-70">↪ Forwarded</p>}
              {qt && <div className="mb-1 rounded-lg border-l-2 border-current bg-black/10 px-2 py-1 text-xs opacity-80"><b>{qt.who}</b><p className="line-clamp-2 break-words">{qt.text}</p></div>}
              {m.deleted_at ? <p className="italic opacity-70">This message was deleted</p>
                : m.kind === 'image' ? (src ? <button onClick={() => setPeek(src)}><img src={src} alt="" className="max-h-64 rounded-xl" /></button> : (offline ? <span className="text-xs opacity-70">Media · connect to view</span> : <div className="h-32 w-40 animate-pulse rounded-xl bg-black/10" />))
                : m.kind === 'video' ? (src ? <video src={src} controls playsInline preload="metadata" className="max-h-64 rounded-xl" /> : (offline ? <span className="text-xs opacity-70">Media · connect to view</span> : <div className="h-32 w-40 animate-pulse rounded-xl bg-black/10" />))
                : m.kind === 'voice' ? (src ? <div className="text-ink"><VoicePlayer src={src} peaks={m.audio_peaks} ms={m.audio_ms} /></div> : (offline ? <span className="text-xs opacity-70">Voice message · connect to play</span> : <div className="h-10 w-48 animate-pulse rounded-full bg-black/10" />))
                : m.kind === 'file' ? <a href={src} target="_blank" rel="noreferrer" download={m.attachment_name ?? undefined} className="flex items-center gap-2"><FileText size={28} /><span className="min-w-0"><b className="block truncate text-sm">{m.attachment_name}</b><small>{size(m.attachment_size)}</small></span></a>
                : <p className="whitespace-pre-wrap break-words">{m.body}</p>}
              {(m.pinned_at || m.edited_at) && !m.deleted_at && <div className="mt-0.5 flex items-center justify-end gap-1 text-[10px] opacity-70">{m.pinned_at && <Pin size={10} />}{m.edited_at && <span>edited</span>}</div>}
              {Object.keys(counts).length > 0 && <div className="mt-1 flex flex-wrap gap-1">{Object.entries(counts).map(([e, n]) => <span key={e} className="rounded-full bg-black/15 px-1.5 text-xs">{e} {n}</span>)}</div>}</div>
            {!m.deleted_at && !m.pending && <button onClick={() => setSheet(m)} aria-label="Message options" className="p-1 text-mute opacity-50"><MoreHorizontal size={16} /></button>}</div>
          {!sameN && <p className={`mt-0.5 flex items-center gap-1 text-[10px] text-mute ${mine ? 'justify-end' : 'ml-9'}`}>{new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            {mine && !m.deleted_at && m.id !== lastMine && (delivered(m) ? <CheckCheck size={12} /> : <Check size={12} />)}</p>}
          {m.id === lastMine && !m.deleted_at && <div className="mt-0.5 flex justify-end gap-0.5">{rd.length ? <>{rd.slice(0, 5).map(r => <Avatar key={r.user_id} a={r.profile} s={14} />)}{rd.length > 5 && <span className="text-[10px] text-mute">+{rd.length - 5}</span>}</> : <span className="text-[10px] text-mute">{m.pending ? (offline ? 'Waiting for network…' : 'Sending…') : delivered(m) ? 'Delivered' : 'Sent'}</span>}</div>}</div>) })}
      {typing && <div className="mt-2 flex items-end gap-1"><div className="w-7 shrink-0"><Avatar a={prof(typing) ?? headAv} s={28} /></div><div aria-label="Typing" className="flex items-center gap-1 rounded-[20px] bg-surface px-4 py-3"><i className="tdot" /><i className="tdot" style={{ animationDelay: '.2s' }} /><i className="tdot" style={{ animationDelay: '.4s' }} /></div></div>}{toast && createPortal(<div className="fixed inset-x-4 top-16 z-[90] mx-auto w-fit max-w-full rounded-2xl bg-surface px-4 py-2 text-center text-sm shadow-xl">{toast}</div>, document.body)}
      {pick && createPortal(<div className="fixed inset-0 z-[80]" onClick={() => setPick(null)} style={{ background: 'rgba(0,0,0,.45)', backdropFilter: 'blur(3px)' }}>
        <div className="absolute flex gap-0.5 rounded-full bg-surface px-2 py-1.5 shadow-2xl" style={{ top: Math.max(80, pick.top - 64), [pick.mine ? 'right' : 'left']: 12 } as React.CSSProperties} onClick={e => e.stopPropagation()}>
          {['❤️', '😂', '😮', '😢', '😡', '👍'].map((em, i) => <button key={em} onClick={() => { react(pick.m, em); setPick(null) }} className="emo-rise p-1.5 text-[28px] leading-none transition-transform active:scale-125" style={{ animationDelay: `${i * 45}ms` }}>{em}</button>)}</div>
        <div className="emo-rise absolute flex flex-col overflow-hidden rounded-2xl bg-surface shadow-2xl" style={{ top: Math.max(80, pick.top - 64) + 66, [pick.mine ? 'right' : 'left']: 12, minWidth: 190, animationDelay: '120ms' } as React.CSSProperties} onClick={e => e.stopPropagation()}>
          <button onClick={() => { setReplyTo(pick.m); setPick(null) }} className="flex items-center gap-3 px-4 py-3 text-left"><Reply size={18} />Reply</button>
          <button onClick={() => { const m = pick.m; setPick(null); openFwd(m) }} className="flex items-center gap-3 border-t border-line px-4 py-3 text-left"><Forward size={18} />Forward</button>
          {pick.m.kind === 'text' && <button onClick={() => { navigator.clipboard?.writeText(pick.m.body); setPick(null) }} className="flex items-center gap-3 border-t border-line px-4 py-3 text-left"><Copy size={18} />Copy</button>}
          <button onClick={() => { const m = pick.m; setPick(null); setSheet(m) }} className="flex items-center gap-3 border-t border-line px-4 py-3 text-left"><MoreHorizontal size={18} />More</button></div>
      </div>, document.body)}<div ref={endRef} /></div>
    <div className="border-t border-line bg-bg p-2" style={{ paddingBottom: 'max(0.5rem, env(safe-area-inset-bottom))' }}>
      {err && <p role="alert" className="px-2 pb-1 text-sm text-red-400">{err}</p>}
      {!isGroup && iBlocked ? <div className="flex items-center justify-between px-2 py-1 text-sm"><span className="text-mute">You blocked this person.</span><button onClick={toggleBlock} className="rounded-full border border-line px-3 py-1">Unblock</button></div>
        : !isGroup && blockedMe ? <p className="px-2 py-2 text-center text-sm text-mute">You can't reply to this conversation.</p>
        : recSecs !== null ? <div className="flex items-center gap-3 px-2 py-1"><i className="h-3 w-3 animate-pulse rounded-full bg-red-500" /><b className="w-12">{mmss(recSecs)}</b><span className="flex-1 text-sm text-mute">Recording…</span>
          <button onClick={() => stopRec(true)} className="rounded-full border border-line px-3 py-1.5 text-sm">Cancel</button><button onClick={() => stopRec(false)} aria-label="Send voice message" className="grid h-11 w-11 place-items-center rounded-full" style={GRAD}><Send size={20} /></button></div>
        : <>{(replyTo || editing) && <div className="mb-2 flex items-center justify-between gap-3 rounded-xl bg-surface px-3 py-2 text-sm"><div className="min-w-0 flex-1 border-l-4 border-accent pl-2">{editing ? <><b className="block text-accent">Editing message</b><span className="block truncate text-mute">{editing.body}</span></> : <><b className="block truncate text-accent">{nameOf(replyTo!.sender_id)}</b><span className="block truncate text-mute">{label(replyTo!)}</span></>}</div><button aria-label="Cancel" onClick={() => { setReplyTo(null); setEditing(null); setText('') }}><X size={16} /></button></div>}
          <div className="flex items-center gap-2">
            <button onClick={() => setAttachOpen(true)} disabled={busy || !!editing} aria-label="Attach" className="p-2 text-accent disabled:opacity-50"><Paperclip size={22} /></button>
            <input ref={bgRef} type="file" accept="image/*" hidden onChange={pickBg} /><input ref={galRef} type="file" accept="image/*" multiple hidden onChange={attach} /><input ref={camRef} type="file" accept="image/*" capture="environment" hidden onChange={attach} /><input ref={vidRef} type="file" accept="video/*" hidden onChange={attach} /><input ref={docRef} type="file" multiple hidden onChange={attachDoc} />
            <input className="min-w-0 flex-1 rounded-full bg-surface px-4 py-2.5 outline-none" maxLength={4000} placeholder={busy ? 'Sending…' : 'Message'} value={text} onChange={e => onType(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }} />
            {text.trim() ? <button onClick={send} aria-label="Send" className="grid h-11 w-11 place-items-center rounded-full" style={GRAD}><Send size={20} /></button>
              : <button onClick={startRec} disabled={busy || !!editing} aria-label="Record voice message" className="grid h-11 w-11 place-items-center rounded-full disabled:opacity-40" style={GRAD}><Mic size={20} /></button>}</div></>}</div>
    {sheet && <Sheet onClose={() => setSheet(null)}><div className="mb-3 flex justify-around">{QUICK.map(e => <button key={e} onClick={() => react(sheet, e)} className="text-3xl active:scale-125">{e}</button>)}</div>
      {actions.map(([I, l, fn, ok]) => ok && <button key={l} onClick={fn} className={`flex w-full items-center gap-3 rounded-xl p-3 text-left hover:bg-bg ${l.startsWith('Delete') || l.startsWith('Report') ? 'text-red-400' : ''}`}><I size={20} />{l}</button>)}</Sheet>}
    {menu && <Sheet onClose={() => setMenu(false)}>
      <button onClick={() => { setMenu(false); setThemeOpen(true) }} className="flex w-full items-center gap-3 rounded-xl p-3 text-left hover:bg-bg"><Palette size={20} className="text-accent" />Chat theme</button>
      <button onClick={() => { setMenu(false); setNickOpen(true) }} className="flex w-full items-center gap-3 rounded-xl p-3 text-left hover:bg-bg"><Pencil size={20} className="text-accent" /><span>Nicknames</span></button>
      {!isGroup && <button onClick={toggleTypingAllow} className="flex w-full items-center gap-3 rounded-xl p-3 text-left hover:bg-bg"><Keyboard size={20} className="text-accent" /><span>{tAllow ? 'Hide my typing status from this person' : 'Show my typing status to this person'}<span className="block text-xs text-mute">Used when “Who can see it” is set to Selected friends</span></span></button>}
      {isGroup && <button onClick={() => { setMenu(false); setGroupInfo(true) }} className="flex w-full items-center gap-3 rounded-xl p-3 text-left hover:bg-bg"><Users size={20} className="text-accent" />Group info & members</button>}
      <button onClick={toggleMute} className="flex w-full items-center gap-3 rounded-xl p-3 text-left hover:bg-bg">{muted ? <Bell size={20} className="text-accent" /> : <BellOff size={20} className="text-accent" />}{muted ? 'Unmute notifications' : 'Mute notifications'}</button>
      {!isGroup && <button onClick={toggleBlock} className="flex w-full items-center gap-3 rounded-xl p-3 text-left text-red-400 hover:bg-bg"><Ban size={20} />{iBlocked ? 'Unblock' : 'Block'}</button>}
      {!isGroup && <button onClick={() => { setMenu(false); setRep({ msg: null }); setRepDone('') }} className="flex w-full items-center gap-3 rounded-xl p-3 text-left text-red-400 hover:bg-bg"><Flag size={20} />Report</button>}</Sheet>}
    {nickOpen && <Sheet onClose={() => { setNickOpen(false); setNickEdit(null) }}><b className="mb-3 block">Nicknames</b>
      <div className="flex max-h-[60vh] flex-col gap-1 overflow-y-auto">{members.map(m => { const p = m.profile; if (!p) return null; const cur = nicks[m.user_id]; const editing = nickEdit?.id === m.user_id
        return (<div key={m.user_id} className="flex items-center gap-3 rounded-xl p-2"><Avatar a={p} s={40} />
          {editing ? <><input autoFocus maxLength={30} value={nickEdit!.v} onChange={e => setNickEdit({ id: m.user_id, v: e.target.value })} onKeyDown={e => { if (e.key === 'Enter') saveNick() }} placeholder="Nickname" className="input min-w-0 flex-1" /><button onClick={saveNick} className="rounded-full bg-accent px-3 py-1.5 text-sm font-semibold text-on">Save</button></>
            : <button onClick={() => setNickEdit({ id: m.user_id, v: cur ?? '' })} className="min-w-0 flex-1 text-left"><span className="block truncate font-medium">{cur || p.full_name || p.username}</span><span className="block truncate text-xs text-mute">{cur ? `${p.full_name || p.username} · tap to change` : 'Set nickname'}</span></button>}</div>) })}</div>
      <p className="mt-2 text-center text-xs text-mute">Everyone in this chat sees these nicknames. Leave it empty and press Save to remove one.</p></Sheet>}
    {attachOpen && <Sheet onClose={() => setAttachOpen(false)}><b className="mb-3 block">Send</b>
      <div className="grid grid-cols-4 gap-2 text-center text-xs">
        {([[ImagePlus, 'Gallery', pickG], [CameraIcon, 'Camera', pickC], [Film, 'Video', () => { setAttachOpen(false); vidRef.current?.click() }], [FileText, 'Document', () => { setAttachOpen(false); docRef.current?.click() }]] as const).map(([I, l, f]) => <button key={l} onClick={f} className="flex flex-col items-center gap-1.5"><span className="grid h-14 w-14 place-items-center rounded-full bg-bg text-accent"><I size={24} /></span>{l}</button>)}</div>
      <p className="mt-3 text-center text-xs text-mute">“Document” sends photos and videos in original quality.</p></Sheet>}
    {editQueue[0] && createPortal(<ImageEditor key={editQueue[0].name + editQueue.length} file={editQueue[0]} onCancel={() => setEditQueue(q => q.slice(1))} onDone={(f, asDoc) => { setEditQueue(q => q.slice(1)); sendAttachment(f, asDoc) }} />, document.body)}
    {themeOpen && <Sheet onClose={() => setThemeOpen(false)}><b className="mb-3 block">Chat theme</b>
      <div className="grid grid-cols-4 gap-3">{Object.entries(PRE).map(([k, v]) => <button key={k} aria-label={k} onClick={() => setBg('p:' + k)} className="h-16 rounded-xl border-2" style={{ background: v, borderColor: myBg === 'p:' + k ? 'var(--accent)' : 'var(--line)' }} />)}</div>
      <button onClick={chooseBg} className="mt-3 flex w-full items-center gap-3 rounded-xl border border-line p-3 text-left"><ImagePlus size={20} className="text-accent" />Choose from gallery</button>
      <button onClick={() => setBg(null)} className="mt-2 w-full rounded-xl p-3 text-left text-mute hover:bg-bg">Reset to default</button></Sheet>}
    {rep && <Sheet onClose={() => setRep(null)}><b className="mb-2 block">Report</b>{repDone ? <p role="status" className="text-accent">{repDone}</p> : REASONS.map(r => <button key={r} onClick={() => report(r)} className="block w-full rounded-xl p-3 text-left hover:bg-bg">{r}</button>)}</Sheet>}
    {fwd && <Sheet onClose={() => { setFwd(null); setFwdSel(new Set()); setFwdQ('') }}>
      <div className="mb-2 flex items-center justify-between"><b>Forward to…</b><span className="text-xs text-mute">{fwdSel.size ? `${fwdSel.size} selected` : 'Tap to select'}</span></div>
      <input className="input mb-2 w-full" placeholder="Search chats" value={fwdQ} onChange={e => setFwdQ(e.target.value)} />
      {!fwdList.length && <p className="py-4 text-center text-mute">Loading chats…</p>}
      <div className="max-h-[45vh] overflow-y-auto">{fwdList.filter(c => (c.title ?? '').toLowerCase().includes(fwdQ.trim().toLowerCase())).map(c => { const on = fwdSel.has(c.id); return (
        <button key={c.id} onClick={() => setFwdSel(cur => { const n = new Set(cur); if (n.has(c.id)) n.delete(c.id); else n.add(c.id); return n })} className="flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-bg"><Avatar a={convAv(c)} s={40} /><b className="min-w-0 flex-1 truncate">{c.title}</b>
          <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 ${on ? 'border-accent bg-accent text-on' : 'border-line'}`}>{on && <Check size={14} />}</span></button>) })}</div>
      <button disabled={!fwdSel.size || fwdBusy} onClick={sendForward} className="mt-3 w-full rounded-xl bg-accent py-3 font-semibold text-on disabled:opacity-50">{fwdBusy ? 'Sending…' : fwdSel.size ? `Send to ${fwdSel.size} chat${fwdSel.size > 1 ? 's' : ''}` : 'Select chats'}</button></Sheet>}
    {groupInfo && isGroup && <GroupInfo cid={cid} conv={conv} members={members.map(m => ({ user_id: m.user_id, role: m.role, profile: m.profile }))} uid={uid} onChanged={loadInfo} onClose={() => setGroupInfo(false)} onLeft={() => nav('/textora')} />}
    {peek && <div className="fixed inset-0 z-[60] grid place-items-center bg-black" onClick={() => setPeek(null)}><img src={peek} alt="" className="max-h-full max-w-full object-contain" /><button className="absolute right-4 top-4 text-white" aria-label="Close"><X /></button></div>}
  </div>)
}
